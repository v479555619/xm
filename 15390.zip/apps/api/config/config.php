<?php
/**
 * @copyright (C)2016-2099 Hnaoyun Inc.
 * @author XingMeng
 * @email hnxsh@foxmail.com
 * @date 2017年11月29日
 *  接口模块配置文件
 */
return array(
    // 控制器返回数据输出方式
    'return_data_type' => 'json'
);